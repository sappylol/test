import json
import os
import shutil
import yt_dlp
from concurrent.futures import ThreadPoolExecutor, as_completed

# ==========================
# CONFIGURAÇÕES
# ==========================
CONFIG = {
    "cache_dir": "cache",               # pasta temporária de download
    "output_dir": "baixados",          # pasta final de saída
    "audio_format": "mp3",              # formato de áudio (mp3, m4a, opus, etc.)
    "audio_quality": "192",             # qualidade do áudio em kbps
    "embed_thumbnail": False,            # incrustar thumbnail no arquivo
    "embed_metadata": True,             # incrustar metadados (título, artista etc.)
    "max_workers": 3,                   # número de downloads simultâneos
    "json_path" : "dados-extraido/resultados_id.json", # arquivo aonde contém os youtube ID

    # Caminho para o binário do ffmpeg (deixe None se já estiver no PATH)
    "ffmpeg_location": None,            # ex: "/usr/bin/ffmpeg" ou "/usr/local/bin"

    # Runtime JS para resolver desafios de assinatura do YouTube (opcional)
    # Valores comuns: None, "deno", "node"
    "js_interpreter": "deno",

    "quiet": False,
}

YOUTUBE_BASE_URL = "https://www.youtube.com/watch?v="


def montar_opcoes_ydl(config, pasta_temp):
    postprocessors = [
        {
            "key": "FFmpegExtractAudio",
            "preferredcodec": config["audio_format"],
            "preferredquality": config["audio_quality"],
        }
    ]

    if config["embed_thumbnail"]:
        postprocessors.append({"key": "EmbedThumbnail"})

    if config["embed_metadata"]:
        postprocessors.append({"key": "FFmpegMetadata"})

    extractor_args = {}
    if config.get("js_interpreter"):
        # Usado por extratores que precisam resolver desafios JS (ex: nsig)
        extractor_args["youtube"] = {"jsinterp": [config["js_interpreter"]]}

    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": f"{pasta_temp}/%(title)s.%(ext)s",
        "postprocessors": postprocessors,
        "writethumbnail": config["embed_thumbnail"],
        "quiet": config["quiet"],
        "noplaylist": True,
        "ignoreerrors": True,
    }

    if config.get("ffmpeg_location"):
        ydl_opts["ffmpeg_location"] = config["ffmpeg_location"]

    if extractor_args:
        ydl_opts["extractor_args"] = extractor_args

    return ydl_opts


def baixar_video(video_id, config):
    url = f"{YOUTUBE_BASE_URL}{video_id}"

    # Pasta temporária exclusiva para esse vídeo
    pasta_temp = os.path.join(config["cache_dir"], video_id)
    os.makedirs(pasta_temp, exist_ok=True)

    ydl_opts = montar_opcoes_ydl(config, pasta_temp)

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            print(f"Iniciando download: {url}")
            ydl.download([url])
            print(f"Concluído: {url}")

        # Move os arquivos finais da pasta temporária para a pasta de output
        os.makedirs(config["output_dir"], exist_ok=True)

        for arquivo in os.listdir(pasta_temp):
            origem = os.path.join(pasta_temp, arquivo)
            destino = os.path.join(config["output_dir"], arquivo)
            shutil.move(origem, destino)

        # Remove a pasta temporária do vídeo
        shutil.rmtree(pasta_temp, ignore_errors=True)

        return video_id, True

    except Exception as e:
        print(f"Erro ao baixar '{url}': {e}")
        shutil.rmtree(pasta_temp, ignore_errors=True)
        return video_id, False


def main():
    with open(CONFIG["json_path"], "r", encoding="utf-8") as f:
        dados_entrada = json.load(f)

    video_ids = dados_entrada.get("resultados", [])

    os.makedirs(CONFIG["cache_dir"], exist_ok=True)
    os.makedirs(CONFIG["output_dir"], exist_ok=True)

    sucesso = []
    falha = []

    with ThreadPoolExecutor(max_workers=CONFIG["max_workers"]) as executor:
        futures = [
            executor.submit(baixar_video, video_id, CONFIG)
            for video_id in video_ids
        ]

        for future in as_completed(futures):
            video_id, ok = future.result()
            if ok:
                sucesso.append(video_id)
            else:
                falha.append(video_id)

    if not os.listdir(CONFIG["cache_dir"]):
        os.rmdir(CONFIG["cache_dir"])

    print(f"\nDownloads concluídos: {len(sucesso)}")
    print(f"Downloads com falha: {len(falha)}")

    if falha:
        with open("downloads_falha.json", "w", encoding="utf-8") as f:
            json.dump({"falhas": falha}, f, ensure_ascii=False, indent=4)
        print("IDs com falha salvos em 'downloads_falha.json'")


if __name__ == "__main__":
    main()